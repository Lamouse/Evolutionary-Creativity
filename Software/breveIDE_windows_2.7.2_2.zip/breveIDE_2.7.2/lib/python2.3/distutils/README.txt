This directory contains only a subset of the Distutils, specifically
the Python modules in the 'distutils' and 'distutils.command'
packages.  This is all you need to distribute and install Python
modules using the Distutils.  There is also a separately packaged
standalone version of the Distutils available for people who want to
upgrade the Distutils without upgrading Python, available from the
Distutils web page:

    http://www.python.org/sigs/distutils-sig/

The standalone version includes all of the code in this directory,
plus documentation, test scripts, examples, etc.

The Distutils documentation is divided into two documents, "Installing
Python Modules", which explains how to install Python packages, and
"Distributing Python Modules", which explains how to write setup.py
files.  Both documents are part of the standard Python documentation
set, and are available from http://www.python.org/doc/current/ .

        Greg Ward (gward@python.net)

$Id: README,v 1.2 2002/11/13 13:26:59 akuchling Exp $
